==WARNING!==
REQUIRED: ClrMamePro 3.90 OR HIGHER
RECOMMENDED: ClrMamePro 3.100 OR HIGHER

==Instructions==

===CM 3.100===
1. Put "No-Intro_FDS.xml" in cmp "headers" folder
2. Load the No-Intro Dat for CM
3. CM will automatically prompt you to load the plugin, click "Yes"

===CM 3.90===
1. Put "No-Intro_FDS.xml" in cmp "headers" folder
2. Load the No-Intro Dat for CM
3. Go in Settings and switch to Headers in the selector
4. Select "No-Intro FDS Dat FWnes Header Skipper"


Now you can scan your set :)

Yakushi~Kabuto

(c) No-Intro World Domination 2007